<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Details Dashboard</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>
    <?php
     include 'casidebar.php';   
    
// Connect to the database
$db = new PDO('mysql:host=localhost;dbname=sesta', 'root', '');

// Create a SQL query to select the ID card data from the database
$sql = "SELECT * FROM id_cards WHERE id = ?";

// Prepare the SQL statement
$stmt = $db->prepare($sql);

// Bind the ID card ID to the prepared statement
$stmt->bindParam(1, $_GET['id']);

// Execute the prepared statement
$stmt->execute();

// Get the ID card data from the prepared statement
$idCardData = $stmt->fetch(PDO::FETCH_ASSOC);

// Create an image canvas
$image = imagecreatetruecolor(300, 200);

// Set the background color of the image
imagefilledrectangle($image, 0, 0, 300, 200, imagecolorallocate($image, 255, 255, 255));

// Add the ID card holder's name to the image
imagettftext($image, 20, 0, 50, 100, imagecolorallocate($image, 0, 0, 0), 'arial.ttf', $idCardData['name']);

// Add the ID card holder's photo to the image
imagecopy($image, imagecreatefromstring($idCardData['photo']), 150, 50, 0, 0, 100, 100);

// Add a border to the image
imagerectangle($image, 0, 0, 299, 199, imagecolorallocate($image, 0, 0, 0));

// Output the image
header('Content-Type: image/jpeg');
imagejpeg($image);

// Destroy the image
imagedestroy($image);

?>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>
