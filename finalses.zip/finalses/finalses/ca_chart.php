<?php
session_start();

// Step 1: Database Connection
include 'configuration.php';
$db = new mysqli($servername, $username, $password, $dbname);

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$ca_id = $_SESSION['ca_id'];

// Retrieve data for the pie chart
$pieChartQuery = "SELECT student_activities.activity_type, COUNT(*) as activity_count
                  FROM student_activities
                  INNER JOIN students ON student_activities.student_id = students.id
                  WHERE students.ca_id = $ca_id
                  GROUP BY student_activities.activity_type";

$pieChartResult = $db->query($pieChartQuery);

$pieLabels = array();
$pieData = array();

while ($row = $pieChartResult->fetch_assoc()) {
    $pieLabels[] = $row['activity_type'];
    $pieData[] = $row['activity_count'];
}

// Retrieve data for the graph chart
$graphChartQuery = "SELECT student_activities.activity_type, COUNT(*) as activity_count
                    FROM student_activities
                    INNER JOIN students ON student_activities.student_id = students.id
                    WHERE students.ca_id = $ca_id
                    GROUP BY student_activities.activity_type";

$graphChartResult = $db->query($graphChartQuery);

$graphLabels = array();
$graphData = array();

while ($row = $graphChartResult->fetch_assoc()) {
    $graphLabels[] = $row['activity_type'];
    $graphData[] = $row['activity_count'];
}

// Close the database connection
$db->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Activity Chart</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="css/style.css">
    
</head>
<body>
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="navbar-brand-wrapper d-flex align-items-center">
          <a class="navbar-brand brand-logo" href="index.html">
            <img src="images/logo.svg" alt="logo" class="logo-dark" />
          </a>
          <a class="navbar-brand brand-logo-mini" href="index.html"><img src="images/logo-mini.svg" alt="logo" /></a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-center flex-grow-1">
          <h5 class="mb-0 font-weight-medium d-none d-lg-flex">Welcome stallar dashboard!</h5>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
              <a href="#" class="nav-link">
                <div class="profile-image">
                  <img class="img-xs rounded-circle" src="images/faces/face8.jpg" alt="profile image">
                  <div class="dot-indicator bg-success"></div>
                </div>
                <div class="text-wrapper">
                  <p class="profile-name">Allen Moreno</p>
                  <p class="designation">Administrator</p>
                </div>
                <div class="icon-container">
                  <i class="icon-bubbles"></i>
                  <div class="dot-indicator bg-danger"></div>
                </div>
              </a>
            </li>
            <li class="nav-item nav-category">
              <span class="nav-link">Dashboard</span>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="caprofile.php">
                <span class="menu-title">Dashboard</span>
                <i class="icon-screen-desktop menu-icon"></i>
              </a>
            </li>
            <li class="nav-item nav-category"><span class="nav-link">Action</span></li>
            <li class="nav-item">
              <div class="collapse" id="ui-basic">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="pages/ui-features/buttons.html">Buttons</a></li>
                  <li class="nav-item"> <a class="nav-link" href="pages/ui-features/typography.html">Typography</a></li>
                </ul>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="pages/icons/simple-line-icons.html">
                <span class="menu-title">Register student</span>
                <i class="icon-globe menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="pages/forms/basic_elements.html">
                <span class="menu-title">Update Student</span>
                <i class="icon-book-open menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="ca_chart.php">
                <span class="menu-title">Charts</span>
                <i class="icon-chart menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#students">
                <span class="menu-title">Tables</span>
                <i class="icon-grid menu-icon"></i>
              </a>
            </li>
            <li class="nav-item nav-category"><span class="nav-link">Home</span></li>
            <li class="nav-item">
            <a class="nav-link" href="logout.php">
                <span class="menu-title">Log Out</span>
                <i class="icon-doc menu-icon"></i>
              </a>
            
              
              
           </li>
             
          </ul>
        </nav>

    <div class="container mt-5">
        <div class="row">
            <div class="col-12 text-center">
                <h1>Student Activity Chart</h1>
            </div>
        </div>
        <div class="row">
            <div class="col-6">
                <h2 style="text-align: center;">Pie Chart</h2>
                <div id="pieChart" style="max-width: 500px; margin: 0 auto;">
                    <canvas id="chartPie"></canvas>
                </div>
            </div>
            <div class="col-6">
                <h2 style="text-align: center;">Graph Chart</h2>
                <div id="graphChart" style="max-width: 500px; margin: 0 auto;">
                    <canvas id="chartGraph"></canvas>
                </div>
            </div>
        </div>

        <script>
            var pieCtx = document.getElementById('chartPie').getContext('2d');
            var pieData = {
                labels: <?php echo json_encode($pieLabels); ?>,
                datasets: [{
                    data: <?php echo json_encode($pieData); ?>,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.6)',
                        'rgba(54, 162, 235, 0.6)',
                        'rgba(255, 206, 86, 0.6)',
                        'rgba(75, 192, 192, 0.6)',
                        'rgba(153, 102, 255, 0.6)',
                        'rgba(255, 159, 64, 0.6)',
                        'rgba(204, 0, 0, 0.6)',
                        'rgba(153, 51, 255, 0.6)',
                        'rgba(0, 128, 0, 0.6)',
                        'rgba(255, 102, 255, 0.6)'
                    ]
                }]
            };

            var pieChart = new Chart(pieCtx, {
                type: 'pie',
                data: pieData
            });

            var graphCtx = document.getElementById('chartGraph').getContext('2d');
            var graphData = {
                labels: <?php echo json_encode($graphLabels); ?>,
                datasets: [{
                    data: <?php echo json_encode($graphData); ?>,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.6)',
                        'rgba(54, 162, 235, 0.6)',
                        'rgba(255, 206, 86, 0.6)',
                        'rgba(75, 192, 192, 0.6)',
                        'rgba(153, 102, 255, 0.6)',
                        'rgba(255, 159, 64, 0.6)',
                        'rgba(204, 0, 0, 0.6)',
                        'rgba(153, 51, 255, 0.6)',
                        'rgba(0, 128, 0, 0.6)',
                        'rgba(255, 102, 255, 0.6)'
                    ]
                }]
            };

            var graphChart = new Chart(graphCtx, {
                type: 'bar',
                data: graphData
            });
        </script>
    </div>
</body>
</html>
