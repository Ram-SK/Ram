<?php
session_start();

// Database connection details
include 'configuration.php';

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



// Get CA's ID from the session

$sql = "SELECT COUNT(*) AS student_count FROM students";
// Query to retrieve student details associated with the CA
$query = "SELECT * FROM students";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Stellar Admin</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="vendors/simple-line-icons/css/simple-line-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <link rel="stylesheet" href="vendors/daterangepicker/daterangepicker.css">
    <link rel="stylesheet" href="vendors/chartist/chartist.min.css">
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="images/favicon.png" />
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_navbar.html -->
      <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="navbar-brand-wrapper d-flex align-items-center">
          <a class="navbar-brand brand-logo" href="index.html">
            <img src="images/logo.svg" alt="logo" class="logo-dark" />
          </a>
          <a class="navbar-brand brand-logo-mini" href="index.html"><img src="images/logo-mini.svg" alt="logo" /></a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-center flex-grow-1">
          <h5 class="mb-0 font-weight-medium d-none d-lg-flex">Welcome SESTA dashboard!</h5>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
              <a href="#" class="nav-link">
                <div class="profile-image">
                  <img class="img-xs rounded-circle" src="images/faces/face8.jpg" alt="profile image">
                  <div class="dot-indicator bg-success"></div>
                </div>
                <div class="text-wrapper">
                  <p class="profile-name">Allen Moreno</p>
                  <p class="designation">Administrator</p>
                </div>
                <div class="icon-container">
                  <i class="icon-bubbles"></i>
                  <div class="dot-indicator bg-danger"></div>
                </div>
              </a>
            </li>
            <li class="nav-item nav-category">
              <span class="nav-link">Dashboard</span>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="caprofile.php">
                <span class="menu-title">Dashboard</span>
                <i class="icon-screen-desktop menu-icon"></i>
              </a>
            </li>
            <li class="nav-item nav-category"><span class="nav-link">Action</span></li>
            <li class="nav-item">
              <div class="collapse" id="ui-basic">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="pages/ui-features/buttons.html">Buttons</a></li>
                  <li class="nav-item"> <a class="nav-link" href="pages/ui-features/typography.html">Typography</a></li>
                </ul>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="pages/icons/simple-line-icons.html">
                <span class="menu-title">Register student</span>
                <i class="icon-globe menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="pages/forms/basic_elements.html">
                <span class="menu-title">Update Student</span>
                <i class="icon-book-open menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="ca_chart.php">
                <span class="menu-title">Charts</span>
                <i class="icon-chart menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#students">
                <span class="menu-title">Tables</span>
                <i class="icon-grid menu-icon"></i>
              </a>
            </li>
            <li class="nav-item nav-category"><span class="nav-link">Home</span></li>
            <li class="nav-item">
            <a class="nav-link" href="logout.php">
                <span class="menu-title">Log Out</span>
                <i class="icon-doc menu-icon"></i>
              </a>
            
              
              
            </li>
            
          </ul>
        </nav>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="row purchace-popup">
              <div class="col-12 stretch-card grid-margin">

              </div>
            </div>
            

  <!-- content -->
  <div class="content ">
            <div class="row row-cols-1 row-cols-md-3 g-4">
                <div class="col-lg-12 col-md-12">
                    <div class="card widget">
                        <div class="card-header">
                            <h5 class="card-title">
                                My Uploaded Certificates - <span style="color:Red;"> (You must upload only .PDF (or) .Jpeg file format / The maximum file size should not exceed 300 KB)</span></h5>
                                
                        </div>
                        <div class="row g-4">
                            <div class="mb-4">
                                <div class="card mb-4">
                                    <div class="card-body">
                                        <div class="row">
                                            
                                            
                                            <div>
	<table class="table table-bordered border-primary" cellspacing="0" rules="all" border="1" id="GvCourse" style="border-collapse:collapse;width: 100%; overflow: scroll;">
		<tr style="color:White;background-color:#FF6E40;">
			<th scope="col">S.No</th><th class="hide" scope="col">Pid</th><th scope="col">Partner Name</th><th scope="col">Course Name</th><th scope="col">Upload Status</th><th scope="col">Profile Link</th><th scope="col">Action</th>
		</tr><tr>
			<td>
                                                            <span id="GvCourse_Sno_0">1</span>
                                                            <input type="hidden" name="GvCourse$ctl02$hd1" id="GvCourse_hd1_0" value="28" />
                                                            <input type="hidden" name="GvCourse$ctl02$hd2" id="GvCourse_hd2_0" value="41" />
                                                            <input type="hidden" name="GvCourse$ctl02$hdstuId" id="GvCourse_hdstuId_0" value="LUB549296" />
                                                        </td><td class="hide">41</td><td>Automation Anywhere</td><td>RPA Essentials</td><td align="center">
                                                           <span id="GvCourse_lblstatus_0"><form action="/upload_certificate.php" method="post" enctype="multipart/form-data">
  <input type="file" name="certificate" accept=".png,.jpeg,.jpg,.pdf">
  
</form></span>
                                                        </td><td align="center">
                                                           
                                                           
                                                          
                                                        </td><td align="center">
                                                           
                                                        </td>
		</tr><tr>
			<td>
                                                            <span id="GvCourse_Sno_1">2</span>
                                                            <input type="hidden" name="GvCourse$ctl03$hd1" id="GvCourse_hd1_1" value="29" />
                                                            <input type="hidden" name="GvCourse$ctl03$hd2" id="GvCourse_hd2_1" value="42" />
                                                            <input type="hidden" name="GvCourse$ctl03$hdstuId" id="GvCourse_hdstuId_1" value="LUB549296" />
                                                        </td><td class="hide">42</td><td>AWS Academy</td><td>Cloud Security Foundations</td><td align="center">
                                                           <span id="GvCourse_lblstatus_1">Not Uploaded</span>
                                                        </td><td align="center">
                                                           
                                                           
                                                          
                                                        </td><td align="center">
                                                           <input type="submit" name="GvCourse$ctl03$btnUpload" value="Submit" id="GvCourse_btnUpload_1" class="btn btn-primary me-2" />
                                                        </td>
		</tr><tr>
			<td>
                                                            <span id="GvCourse_Sno_2">3</span>
                                                            <input type="hidden" name="GvCourse$ctl04$hd1" id="GvCourse_hd1_2" value="32" />
                                                            <input type="hidden" name="GvCourse$ctl04$hd2" id="GvCourse_hd2_2" value="49" />
                                                            <input type="hidden" name="GvCourse$ctl04$hdstuId" id="GvCourse_hdstuId_2" value="LUB549296" />
                                                        </td><td class="hide">49</td><td>Bentley Education</td><td>Modelling Structures with Analytical Modeler using STADD.Pro</td><td align="center">
                                                           <span id="GvCourse_lblstatus_2">Cerificate Uploaded</span>
                                                        </td><td align="center">
                                                           
                                                           
                                                          
                                                        </td><td align="center">
                                                           
                                                        </td>
		</tr><tr>
			<td>
                                                            <span id="GvCourse_Sno_3">4</span>
                                                            <input type="hidden" name="GvCourse$ctl05$hd1" id="GvCourse_hd1_3" value="32" />
                                                            <input type="hidden" name="GvCourse$ctl05$hd2" id="GvCourse_hd2_3" value="50" />
                                                            <input type="hidden" name="GvCourse$ctl05$hdstuId" id="GvCourse_hdstuId_3" value="LUB549296" />
                                                        </td><td class="hide">50</td><td>Bentley Education</td><td>2D/3D Modeling of Building Environment with Microstation</td><td align="center">
                                                           <span id="GvCourse_lblstatus_3">Cerificate Uploaded</span>
                                                        </td><td align="center">
                                                           
                                                           
                                                          
                                                        </td><td align="center">
                                                           
                                                        </td>
		</tr><tr>
			<td>
                                                            <span id="GvCourse_Sno_4">5</span>
                                                            <input type="hidden" name="GvCourse$ctl06$hd1" id="GvCourse_hd1_4" value="27" />
                                                            <input type="hidden" name="GvCourse$ctl06$hd2" id="GvCourse_hd2_4" value="40" />
                                                            <input type="hidden" name="GvCourse$ctl06$hdstuId" id="GvCourse_hdstuId_4" value="LUB549296" />
                                                        </td><td class="hide">40</td><td>Celonis</td><td>Rising Star Technical</td><td align="center">
                                                           <span id="GvCourse_lblstatus_4">Cerificate Uploaded</span>
                                                        </td><td align="center">
                                                           
                                                           
                                                          
                                                        </td><td align="center">
                                                           
                                                        </td>
		</tr><tr>
			<td>
                                                            <span id="GvCourse_Sno_5">6</span>
                                                            <input type="hidden" name="GvCourse$ctl07$hd1" id="GvCourse_hd1_5" value="30" />
                                                            <input type="hidden" name="GvCourse$ctl07$hd2" id="GvCourse_hd2_5" value="43" />
                                                            <input type="hidden" name="GvCourse$ctl07$hdstuId" id="GvCourse_hdstuId_5" value="LUB549296" />
                                                        </td><td class="hide">43</td><td>Google</td><td>Android Basics with Compose</td><td align="center">
                                                           <span id="GvCourse_lblstatus_5">Not Uploaded</span>
                                                        </td><td align="center">
                                                           
                                                           <textarea name="GvCourse$ctl07$txtlink" rows="2" cols="20" id="GvCourse_txtlink_5">
</textarea>
                                                          
                                                        </td><td align="center">
                                                           <input type="submit" name="GvCourse$ctl07$btnUpload" value="Submit" id="GvCourse_btnUpload_5" class="btn btn-primary me-2" />
                                                        </td>
		</tr><tr>
			<td>
                                                            <span id="GvCourse_Sno_6">7</span>
                                                            <input type="hidden" name="GvCourse$ctl08$hd1" id="GvCourse_hd1_6" value="30" />
                                                            <input type="hidden" name="GvCourse$ctl08$hd2" id="GvCourse_hd2_6" value="65" />
                                                            <input type="hidden" name="GvCourse$ctl08$hdstuId" id="GvCourse_hdstuId_6" value="LUB549296" />
                                                        </td><td class="hide">65</td><td>Google</td><td>Machine Learning with TensorFlow</td><td align="center">
                                                           <span id="GvCourse_lblstatus_6">Not Uploaded</span>
                                                        </td><td align="center">
                                                           
                                                           <textarea name="GvCourse$ctl08$txtlink" rows="2" cols="20" id="GvCourse_txtlink_6">
</textarea>
                                                          
                                                        </td><td align="center">
                                                           <input type="submit" name="GvCourse$ctl08$btnUpload" value="Submit" id="GvCourse_btnUpload_6" class="btn btn-primary me-2" />
                                                        </td>
		</tr><tr>
			<td>
                                                            <span id="GvCourse_Sno_7">8</span>
                                                            <input type="hidden" name="GvCourse$ctl09$hd1" id="GvCourse_hd1_7" value="34" />
                                                            <input type="hidden" name="GvCourse$ctl09$hd2" id="GvCourse_hd2_7" value="56" />
                                                            <input type="hidden" name="GvCourse$ctl09$hdstuId" id="GvCourse_hdstuId_7" value="LUB549296" />
                                                        </td><td class="hide">56</td><td>IITM Pravartak Catalysing Innovation</td><td>Introduction to Banking and Finance</td><td align="center">
                                                           <span id="GvCourse_lblstatus_7">Not Uploaded</span>
                                                        </td><td align="center">
                                                           
                                                           
                                                          
                                                        </td><td align="center">
                                                           <input type="submit" name="GvCourse$ctl09$btnUpload" value="Submit" id="GvCourse_btnUpload_7" class="btn btn-primary me-2" />
                                                        </td>
		</tr><tr>
			<td>
                                                            <span id="GvCourse_Sno_8">9</span>
                                                            <input type="hidden" name="GvCourse$ctl10$hd1" id="GvCourse_hd1_8" value="34" />
                                                            <input type="hidden" name="GvCourse$ctl10$hd2" id="GvCourse_hd2_8" value="63" />
                                                            <input type="hidden" name="GvCourse$ctl10$hdstuId" id="GvCourse_hdstuId_8" value="LUB549296" />
                                                        </td><td class="hide">63</td><td>IITM Pravartak Catalysing Innovation</td><td>Introduction to Supply Chain Management</td><td align="center">
                                                           <span id="GvCourse_lblstatus_8">Not Uploaded</span>
                                                        </td><td align="center">
                                                           
                                                           
                                                          
                                                        </td><td align="center">
                                                           <input type="submit" name="GvCourse$ctl10$btnUpload" value="Submit" id="GvCourse_btnUpload_8" class="btn btn-primary me-2" />
                                                        </td>
		</tr><tr>
			<td>
                                                            <span id="GvCourse_Sno_9">10</span>
                                                            <input type="hidden" name="GvCourse$ctl11$hd1" id="GvCourse_hd1_9" value="34" />
                                                            <input type="hidden" name="GvCourse$ctl11$hd2" id="GvCourse_hd2_9" value="57" />
                                                            <input type="hidden" name="GvCourse$ctl11$hdstuId" id="GvCourse_hdstuId_9" value="LUB549296" />
                                                        </td><td class="hide">57</td><td>IITM Pravartak Catalysing Innovation</td><td>Introduction to Securities Operations and Risk Management</td><td align="center">
                                                           <span id="GvCourse_lblstatus_9">Not Uploaded</span>
                                                        </td><td align="center">
                                                           
                                                           
                                                          
                                                        </td><td align="center">
                                                           <input type="submit" name="GvCourse$ctl11$btnUpload" value="Submit" id="GvCourse_btnUpload_9" class="btn btn-primary me-2" />
                                                        </td>
		</tr><tr>
			<td>
                                                            <span id="GvCourse_Sno_10">11</span>
                                                            <input type="hidden" name="GvCourse$ctl12$hd1" id="GvCourse_hd1_10" value="31" />
                                                            <input type="hidden" name="GvCourse$ctl12$hd2" id="GvCourse_hd2_10" value="48" />
                                                            <input type="hidden" name="GvCourse$ctl12$hdstuId" id="GvCourse_hdstuId_10" value="LUB549296" />
                                                        </td><td class="hide">48</td><td>Juniper Networks</td><td>Introduction to Juniper Mist AI</td><td align="center">
                                                           <span id="GvCourse_lblstatus_10">Not Uploaded</span>
                                                        </td><td align="center">
                                                           
                                                           
                                                          
                                                        </td><td align="center">
                                                           <input type="submit" name="GvCourse$ctl12$btnUpload" value="Submit" id="GvCourse_btnUpload_10" class="btn btn-primary me-2" />
                                                        </td>
		</tr><tr>
			<td>
                                                            <span id="GvCourse_Sno_11">12</span>
                                                            <input type="hidden" name="GvCourse$ctl13$hd1" id="GvCourse_hd1_11" value="31" />
                                                            <input type="hidden" name="GvCourse$ctl13$hd2" id="GvCourse_hd2_11" value="47" />
                                                            <input type="hidden" name="GvCourse$ctl13$hdstuId" id="GvCourse_hdstuId_11" value="LUB549296" />
                                                        </td><td class="hide">47</td><td>Juniper Networks</td><td>Introduction to the Junos Operating System (IJOS)</td><td align="center">
                                                           <span id="GvCourse_lblstatus_11">Not Uploaded</span>
                                                        </td><td align="center">
                                                           
                                                           
                                                          
                                                        </td><td align="center">
                                                           <input type="submit" name="GvCourse$ctl13$btnUpload" value="Submit" id="GvCourse_btnUpload_11" class="btn btn-primary me-2" />
                                                        </td>
		</tr><tr>
			<td>
                                                            <span id="GvCourse_Sno_12">13</span>
                                                            <input type="hidden" name="GvCourse$ctl14$hd1" id="GvCourse_hd1_12" value="26" />
                                                            <input type="hidden" name="GvCourse$ctl14$hd2" id="GvCourse_hd2_12" value="39" />
                                                            <input type="hidden" name="GvCourse$ctl14$hdstuId" id="GvCourse_hdstuId_12" value="LUB549296" />
                                                        </td><td class="hide">39</td><td>MathWorks</td><td>Computer Vision on Ramp</td><td align="center">
                                                           <span id="GvCourse_lblstatus_12">Cerificate Uploaded</span>
                                                        </td><td align="center">
                                                           
                                                           
                                                          
                                                        </td><td align="center">
                                                           
                                                        </td>
		</tr><tr>
			<td>
                                                            <span id="GvCourse_Sno_13">14</span>
                                                            <input type="hidden" name="GvCourse$ctl15$hd1" id="GvCourse_hd1_13" value="25" />
                                                            <input type="hidden" name="GvCourse$ctl15$hd2" id="GvCourse_hd2_13" value="37" />
                                                            <input type="hidden" name="GvCourse$ctl15$hdstuId" id="GvCourse_hdstuId_13" value="LUB549296" />
                                                        </td><td class="hide">37</td><td>Microsoft</td><td>Machine Learning Challenge</td><td align="center">
                                                           <span id="GvCourse_lblstatus_13">Not Uploaded</span>
                                                        </td><td align="center">
                                                           
                                                           
                                                          
                                                        </td><td align="center">
                                                           <input type="submit" name="GvCourse$ctl15$btnUpload" value="Submit" id="GvCourse_btnUpload_13" class="btn btn-primary me-2" />
                                                        </td>
		</tr><tr>
			<td>
                                                            <span id="GvCourse_Sno_14">15</span>
                                                            <input type="hidden" name="GvCourse$ctl16$hd1" id="GvCourse_hd1_14" value="25" />
                                                            <input type="hidden" name="GvCourse$ctl16$hd2" id="GvCourse_hd2_14" value="38" />
                                                            <input type="hidden" name="GvCourse$ctl16$hdstuId" id="GvCourse_hdstuId_14" value="LUB549296" />
                                                        </td><td class="hide">38</td><td>Microsoft</td><td>AI Builder Challenge</td><td align="center">
                                                           <span id="GvCourse_lblstatus_14">Not Uploaded</span>
                                                        </td><td align="center">
                                                           
                                                           
                                                          
                                                        </td><td align="center">
                                                           <input type="submit" name="GvCourse$ctl16$btnUpload" value="Submit" id="GvCourse_btnUpload_14" class="btn btn-primary me-2" />
                                                        </td>
		</tr><tr>
			
	</table>
</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
        <!-- ./ content -->
            
  </body>
</html>