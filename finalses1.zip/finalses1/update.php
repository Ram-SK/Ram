<!DOCTYPE html>
<html>
<head>
    <title>Edit Student</title>
    <link rel="stylesheet" href="style.css">
     
    <!----===== Iconscout CSS ===== -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <!-- Include Bootstrap CSS for styling -->
    
</head>
<body>
    <div class="container">
        <h2>Edit Student</h2>
        <?php
        // Database connection code (replace with your actual database credentials)
       include 'configuration.php';
        // Create a connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check the connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        if (isset($_GET['id'])) {
            $id = $_GET['id'];

            // Fetch the student data by ID
            $query = "SELECT * FROM students WHERE id = $id";

            $result = $conn->query($query);

            if ($result->num_rows > 0) {
                $studentData = $result->fetch_assoc();
                ?>
                <form action="update_process.php" method="post">
                    <input type="hidden" name="id" value="<?= $studentData['id'] ?>">
                    <div class="form-group">
                        <label for="firstname">First Name:</label>
                        <input type="text" name="firstname" class="form-control" value="<?= $studentData['firstname'] ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="lastname">Last Name:</label>
                        <input type="text" name="lastname" class="form-control" value="<?= $studentData['lastname'] ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="text" name="email" class="form-control" value="<?= $studentData['email'] ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="gender">Gender:</label>
                        <input type="text" name="gender" class="form-control" value="<?= $studentData['gender'] ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="dob">Date of Birth:</label>
                        <input type="text" name="dob" class="form-control" value="<?= $studentData['dob'] ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="dob">phone:</label>
                        <input type="text" name="phone" class="form-control" value="<?= $studentData['phone'] ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="mentor_id">Mentor ID:</label>
                        <input type="text" name="mentor_id" class="form-control" value="<?= $studentData['mentor_id'] ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="year_of_study">Year of Study:</label>
                        <input type="text" name="year_of_study" class="form-control" value="<?= $studentData['year_of_study'] ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="branch">Branch:</label>
                        <input type="text" name="branch" class="form-control" value="<?= $studentData['branch'] ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="section">Section:</label>
                        <input type="text" name="section" class="form-control" value="<?= $studentData['section'] ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="credit_points">Credit Points:</label>
                        <input type="text" name="credit_points" class="form-control" value="<?= $studentData['credit_points'] ?>" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Update Student</button>
                </form>


                
            <?php
            } else {
                echo 'Student not found';
            }
        } else {
            echo 'Invalid request';
        }

        // Close the database connection
        $conn->close();
        ?>
    </div>
</body>
</html>
