<?php
session_start();

// Database connection details
include 'configuration.php';

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the student ID from the URL parameter
$student_id = $_GET['id'];

// Query to retrieve activities for the selected student
$query = "SELECT * FROM student_activities WHERE student_id = $student_id";
$result = $conn->query($query);

// Retrieve student details
$query_student = "SELECT * FROM students WHERE id = $student_id";
$result_student = $conn->query($query_student);
$student = $result_student->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Activities</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Student Activities for <?php echo $student['firstname'] . " " . $student['lastname']; ?></h1>
        <a href="ca_dashboard.php" class="btn btn-primary">Back to CA Dashboard</a>

        <?php
        if ($result->num_rows > 0) {
            echo "<h2 class='mt-4'>Activities List:</h2>";
            echo "<table class='table'>";
            echo "<thead><tr><th>Certificate Name</th><th>Topic</th><th>Credit Points</th><th>Status</th></tr></thead>";
            echo "<tbody>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['activity_type'] . "</td>";
                echo "<td>" . $row['topic'] . "</td>";
                echo "<td>" . $row['credit_points'] . "</td>";
                echo "<td>" . $row['status'] . "</td>";
                echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";
        } else {
            echo "<p>No activities found for this student.</p>";
        }

        // Close the database connection
        $conn->close();
        ?>
    </div>
</body>
</html>
