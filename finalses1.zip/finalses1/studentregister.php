<?php
session_start();

// Database connection details
include 'configuration.php';

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



// Get CA's ID from the session
$ca_id = $_SESSION['ca_id'];

$sql = "SELECT COUNT(*) AS student_count FROM students WHERE ca_id = $ca_id";
// Query to retrieve student details associated with the CA
$query = "SELECT * FROM students WHERE ca_id = $ca_id";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<!--=== Coding by CodingLab | www.codinglabweb.com === -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->
    <link rel="stylesheet" href="style.css">
     
    <!----===== Iconscout CSS ===== -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">

    <title>Responsive Regisration Form </title> 
</head>
<body>
  <?php

  include 'sidebar.php';

  ?>
    <div class="container">
        <header>Student Registration</header>

        <form method="POST" action="process_registration.php">
            
                <div class="details personal">
                    <span class="title">Personal Details</span>

                    <div class="fields">
                        <div class="input-field">
                            <label>First Name </label>
                            <input type="text" id="firstname" placeholder="Enter your name" name="firstname" required>
                        </div>

                        <div class="input-field">
                            <label>Last Name</label>
                            <input type="text" name="lastname" placeholder="Enter your ccupation" required>
                        </div>

                        <div class="input-field">
                            <label>Date of Birth</label>
                            <input type="date" name="dob" placeholder="Enter birth date" required>
                        </div>

                        <div class="input-field">
                            <label>Date of Birth</label>
                            <input type="date" name="password" placeholder="Enter birth date" required>
                        </div>
                        <div class="input-field">
                            <label>Email</label>
                            <input type="text" name="email" placeholder="Enter your email" required>
                        </div>

                        <div class="input-field">
                            <label>Mobile Number</label>
                            <input type="number" name="phone" placeholder="Enter mobile number" required>
                        </div>

                        <div class="input-field">
                            <label>Gender</label>
                            <select required name="gender">
                                <option disabled selected>Select gender</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
            
                            </select>
                        </div>

                        
                  
                </div>

                <div class="details ID">
                    <span class="title">Identity Details</span>

                    <div class="fields">
                        <div class="input-field">
                            <label>Roll Number(username)</label>
                            <input type="text" name="rollnumber" placeholder="Enter ID type" required>
                        </div>

                        <div class="input-field">
                            <label>Year Of Study</label>
                            <select required name="year">
                                <option disabled selected>Select Year Of Study</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Branch of Study</label>
                            <select required name="department">
                                <option disabled selected>Select Branch of Study</option>
                                <option value="it">IT</option>
                                <option value="cs">CS</option>
                                <option value="ece">ECE</option>
                                <option value="eee">EEE</option>
                            </select>
                          </div>

                        <div class="input-field">
                            <label>Section</label>
                            <select required name="section">
                                <option disabled selected>Select Section</option>
                                <option value="a">A</option>
                                <option value="b">B</option>
                                <option value="c">C</option>
                                
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Class Adivisor Name</label>
                            <select required name="ca">
                                <option disabled selected>Select Class Advisor</option>
                                <option value="kalaimam">Kalayarasi Mam</option>
                                <option value="akilamam">Akila Mam</option>
                                <option value="manisir">Manivel Sir</option>
                                <option value="buvaneshwarimam">Buvaneshwari Mam</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Mentor Name</label>
                            <select required name="ment">
                                <option disabled selected>Select Class Advisor</option>
                                <option>Dhamodaran Sir</option>
                                <option>Kalayarasi Mam</option>
                                <option>Manivel Sir</option>
                                <option>Buvaneshwari Mam</option>
                            </select>
                                                    
                          </div>
                    </div>

                    
                </div> 
            </div>
            <center>

            <button type="submit">submit</button>
            </center>
                </div> 
            </div>
        </form>
    </div>

    <script src="script.js"></script>
</body>
</html>