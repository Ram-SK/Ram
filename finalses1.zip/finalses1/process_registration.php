<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css">
</head>
<body>
    
<?php
// Include your database connection code here (e.g., connection details, functions).
// Replace the placeholders with your actual database connection information.
include 'configuration.php';

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process the form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstname = $_POST["firstname"];
    $lastname = $_POST["lastname"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $gender = $_POST["gender"];
    $dob = $_POST["dob"];
    $year_of_study = $_POST["year"];
    $branch = $_POST["department"];
    $section = $_POST["section"];
    $phone = $_POST["phone"];
    $ment = $_POST["ment"];
    $ca = $_POST["ca"];

    // Perform any necessary validation on the form data here

    // Check if the email already exists in the database
    $checkEmailSQL = "SELECT email FROM students WHERE email = '$email'";
    $result = $conn->query($checkEmailSQL);

    if ($result->num_rows > 0) {
        echo '<h1 class="display-4">you are already registered this email</h1>';
        echo "<p class='text-danger'>Email alread exists. Please use a different email address.</p>";
        echo "<a href='admin_login.php' class='btn btn-secondary'>login page</a>";
    } else {
        // Insert data into the database
        $sql = "INSERT INTO students (firstname, lastname, email, password, gender, dob, mentor_id, ca_id, year_of_study, branch, section, phone)
                VALUES ('$firstname', '$lastname', '$email', '$password', '$gender', '$dob', '$ment', '$ca', '$year_of_study', '$branch', '$section', '$phone')";

        if ($conn->query($sql) === true) {
            echo "Registration successful!";
            echo "<a href='studentlogin.php' class='text-danger'>Back to login</a>";
            
        } else {
            echo "<p class='text-danger'>Error: " . $sql . "<br>" . $conn->error . "</p>";
        }
    }

    // Close the database connection
    $conn->close();
}
?>

</body>
</html>